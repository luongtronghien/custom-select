var L10n = {
  message: {
    manifest: 'A new version of this page is available. Do you want to reload now?'
  },
  group: {
    key: 'value'
  }
};
