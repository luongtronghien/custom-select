exports['index'] = function(req, res) {
  res.render('index');
};

exports['sitemap'] = function(req, res) {
  res.render('sitemap');
};

